# Datfic

##### [/datfic/] n.m. (21th century)

1. Portemeanteau for *data* and *fiction*; stories made out of data.
1. Fictional story made by data fanatics (see *fanfic*).
1. New perceptions of data based on experience ; *Visualization is so trivially ocular. Datfics should appeal to our five senses.*
