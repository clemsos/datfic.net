---
layout: page
title: Workshop Data Fiction - HEAD
---

M1 Media Design  
**January 8-12th, 2018**  
HEAD, Geneva - Switzerland  

![](https://head.hesge.ch/alpes/assets/images/Head_logocourt_NB.jpg)


* Voir le [déroulement](./content.html)
* Lire [l'énoncé](./assignment.html)

### Credits

* Clément Renaud
* Léo Durand
* Simon Pinkas
* Romain Talou
* Ghofran Akil
* Carla Marceau
* Mathias Hangartner
* Nicolas Baldran
* Salomé Faure
* David Héritier
