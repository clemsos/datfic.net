---
layout: home
id: home
title: Datfic
---

# Datfic

##### [/datfic/] n.m. (21th century)

1. Portemanteau for *data* and *fiction*; stories made out of data.
1. Fictional story made by data fanatics (see *fanfic*).
1. Experimental writing pipelines ; ex: *This data made me immensely sick and happy.*
